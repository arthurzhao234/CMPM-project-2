extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if not body.is_in_group("player"):
		return

	print("portal3 reset score")

	GameManager.reset_score()
	GameManager.set_checkpoint($DestinationPoint.global_position)
	body.global_position = $DestinationPoint.global_position
