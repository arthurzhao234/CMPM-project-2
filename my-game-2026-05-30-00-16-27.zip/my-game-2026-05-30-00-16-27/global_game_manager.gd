extends Node

signal score_changed(score: int)

var score: int = 0:
	set(value):
		if score == value:
			return
		score = value
		score_changed.emit(score)

func add_point(amount: int = 30) -> void:
	score += amount

func reset_score() -> void:
	score = 0
	
var has_checkpoint: bool = false
var checkpoint_position: Vector2 = Vector2.ZERO

func set_checkpoint(pos: Vector2) -> void:
	has_checkpoint = true
	checkpoint_position = pos
	print("Checkpoint saved at: ", pos)
