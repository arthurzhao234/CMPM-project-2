extends Area2D
func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		print("2")
		var gate2 = get_tree().current_scene.get_node("AutoUnlockGate2")
		gate2.required_score = 900

		print("portal reset score")
		GameManager.reset_score()
		GameManager.set_checkpoint(Vector2(1496, -1256))
		body.global_position = $DestinationPoint.global_position
