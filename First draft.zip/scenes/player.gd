# 继承自CharacterBody2D节点，用于2D角色的物理运动
extends CharacterBody2D

# 角色移动速度常量
const SPEED = 150.0
# 跳跃初速度常量（负值表示向上）
const JUMP_VELOCITY = -300.0
# 重力缩放系数 - 控制正常下落速度
const GRAVITY_SCALE = 1.0
# 滑翔时的重力缩放 - 数值越小，下落越慢（已调整为更慢）
const GLIDE_GRAVITY_SCALE = 0.15  # 从0.3调整为0.15，降落速度减慢一半
# 滑翔时的水平速度加成
const GLIDE_SPEED_BOOST = 1.5
const QUESTION_BLOCK_CENTER = Vector2(1083.19, -514.845)
const QUESTION_BLOCK_TRIGGER_DISTANCE = 56.0
const QUESTION_BLOCK_CELL = Vector2i(66, -33)

var escaped_world := false
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
@onready var end_message_label: Label = get_node_or_null("../GameManager/EndMessageLabel")

# 跳跃次数计数器
var jump_count = 0
# 最大跳跃次数
const MAX_JUMPS = 2

# 物理帧更新函数，每帧调用，参数delta为帧间隔时间
func _physics_process(delta: float) -> void:

 
	
	
	# 检查是否在地面上，重置跳跃次数
	if is_on_floor():
		jump_count = 0
	
	# 应用重力，根据是否滑翔使用不同的重力系数
	var current_gravity = get_gravity()
	if is_gliding():
		current_gravity *= GLIDE_GRAVITY_SCALE  # 使用更慢的滑翔重力
	else:
		current_gravity *= GRAVITY_SCALE
		
	if not is_on_floor():
		velocity += current_gravity * delta
		
	# 处理跳跃逻辑
	if Input.is_action_just_pressed("jump") and jump_count < MAX_JUMPS:
		jump_count += 1
		velocity.y = JUMP_VELOCITY  # 跳跃速度
		
	# 处理移动逻辑，滑翔时增加水平速度
	var direction := Input.get_axis("move_left", "move_right")
	# 根据输入方向控制角色的朝向（通过翻转精灵实现）
	if  direction > 0:
		 # 当向右移动时（输入为正），不翻转精灵（保持原始朝向，通常为右）
		animated_sprite_2d.flip_h = false
	elif direction < 0:
		 # 当向左移动时（输入为负），水平翻转精灵（使其朝向左侧）
		animated_sprite_2d.flip_h = true
		
		
#	if direction ==0:
#		animated_sprite_2d.play("default")
#	else:
#		animated_sprite_2d.play("run")

	if is_on_floor():
		if direction ==0:
			animated_sprite_2d.play("IDLE")
		else:
			animated_sprite_2d.play("run")
	else:
		animated_sprite_2d.play("jump")
	
	var current_speed = SPEED
	
	
	# 如果正在滑翔且有水平输入，增加移动速度
	if is_gliding() and direction != 0:
		current_speed *= GLIDE_SPEED_BOOST
		
	if direction:
		velocity.x = direction * current_speed
	else:
		# 没有输入时减速
		velocity.x = move_toward(velocity.x, 0, current_speed)
		

	# 应用移动并处理碰撞
	move_and_slide()
	check_question_block_touch()

# 检查是否正在滑翔
func is_gliding() -> bool:
	# 滑翔条件：
	# 1. 不在地面上
	# 2. 已经跳跃过至少一次
	# 3. 按下滑键或同时按下方向下和左右键
	var is_in_air = not is_on_floor()
	var has_jumped = jump_count > 0
	var pressing_down = Input.is_action_pressed("ui_down")
	var pressing_horizontal = Input.is_action_pressed("move_left") or Input.is_action_pressed("move_right")
	
	var glide_input = pressing_down || (pressing_down && pressing_horizontal)
	
	return is_in_air && has_jumped && glide_input
	
	
func check_question_block_touch() -> void:
	if escaped_world:
		return

	var player_collision_center := global_position + Vector2(12, 12)
	if player_collision_center.distance_to(QUESTION_BLOCK_CENTER) > QUESTION_BLOCK_TRIGGER_DISTANCE:
		var touched_question_block := false
		for collision_index in range(get_slide_collision_count()):
			var collision := get_slide_collision(collision_index)
			var tile_map := collision.get_collider() as TileMap
			if tile_map == null:
				continue

			var local_point := tile_map.to_local(collision.get_position() - collision.get_normal())
			var cell := tile_map.local_to_map(local_point)
			if abs(cell.x - QUESTION_BLOCK_CELL.x) <= 1 and abs(cell.y - QUESTION_BLOCK_CELL.y) <= 1:
				touched_question_block = true
				break

		if not touched_question_block:
			return

	escaped_world = true
	velocity = Vector2.ZERO
	if end_message_label:
		end_message_label.text = "You have escaped this world"
		end_message_label.visible = true
