extends Area2D

@export var end_message_label_path: NodePath = NodePath("../GameManager/EndMessageLabel")

var finished := false
@onready var end_message_label: Label = get_node(end_message_label_path)

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
	if finished or body.name != "Player":
		return

	finished = true
	end_message_label.visible = true

	if body is CharacterBody2D:
		body.velocity = Vector2.ZERO
		body.set_physics_process(false)
