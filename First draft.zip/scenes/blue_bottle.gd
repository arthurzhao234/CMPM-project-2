extends Area2D

@export var tile_map_path: NodePath = NodePath("../TileMap")
@export var hint_label_path: NodePath = NodePath("../GameManager/HintLabel")
@export var gate_layer: int = 1
@export var gate_x: int = 52
@export var gate_y_start: int = -36
@export var gate_y_end: int = -27
@export var required_score: int = 30

var unlocked := false

@onready var tile_map: TileMap = get_node(tile_map_path)
@onready var hint_label: Label = get_node(hint_label_path)

func _ready() -> void:
	hint_label.visible = false
	GameManager.score_changed.connect(_on_score_changed)
	check_unlock()

func _process(_delta: float) -> void:
	check_unlock()

func _on_score_changed(_score: int) -> void:
	check_unlock()

func check_unlock() -> void:
	if unlocked:
		return

	if GameManager.score >= required_score:
		unlock_gate()

func unlock_gate() -> void:
	unlocked = true
	hint_label.visible = false

	var start_y = min(gate_y_start, gate_y_end)
	var end_y = max(gate_y_start, gate_y_end)
	for y in range(start_y, end_y + 1):
		tile_map.erase_cell(gate_layer, Vector2i(gate_x, y))
