extends CanvasLayer

@onready var scorelabel: Label = $ScoreLabel

func _ready() -> void:
	GameManager.score_changed.connect(_on_score_changed)
	update_score_label()

func add_point() -> void:
	GameManager.add_point()
	print("score:", GameManager.score)

func _on_score_changed(_score: int) -> void:
	update_score_label()

func update_score_label() -> void:
	scorelabel.text = "score:" + str(GameManager.score)
