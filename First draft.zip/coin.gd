extends Area2D

@onready var game_manager: Node = %GameManager

@onready var animation_player: AnimationPlayer = $AnimationPlayer



func _on_body_entered(body: Node2D) -> void:
	
	
	print ("+1 coin")
	game_manager.add_point() # 调用game_manager的新增金币方法
	animation_player.play("Pickup")
	
	#queue_free()
	pass # Replace with function body.
