extends Node

signal score_changed(score: int)

var score: int = 0:
	set(value):
		if score == value:
			return
		score = value
		score_changed.emit(score)

func add_point(amount: int = 1) -> void:
	score += amount

func reset_score() -> void:
	score = 0
